#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail=0
ok(){ echo "[OK] $1"; }
warn(){ echo "[WARN] $1"; }
bad(){ echo "[FAIL] $1"; fail=1; }

echo "== Kibriya Chat full static audit =="
for f in pubspec.yaml lib/main.dart lib/core/theme.dart android/settings.gradle android/app/build.gradle android/app/src/main/AndroidManifest.xml server/package.json server/src/server.js; do
  test -f "$f" && ok "exists: $f" || bad "missing: $f"
done

for d in lib android server assets; do test -d "$d" && ok "directory: $d" || bad "missing directory: $d"; done

# Android manifest references.
grep -q 'android:icon="@mipmap/ic_launcher"' android/app/src/main/AndroidManifest.xml && test -f android/app/src/main/res/mipmap-mdpi/ic_launcher.png \
  && ok "Android launcher icon exists" || bad "Android launcher icon is missing"

grep -q 'usesCleartextTraffic="${cleartextTraffic}"' android/app/src/main/AndroidManifest.xml \
  && grep -q 'cleartextTraffic: "false"' android/app/build.gradle \
  && ok "release cleartext traffic is disabled" || bad "release cleartext traffic is not explicitly disabled"

grep -q 'signingConfigs.release' android/app/build.gradle && ok "release signing config is wired" || bad "release signing config missing"

grep -q 'android/key.properties' .gitignore && ok "signing secrets ignored" || bad "android/key.properties is not ignored"

# Asset references: every explicit local asset path must exist.
python3 - <<'PY'
from pathlib import Path
import re, sys
root=Path('.')
missing=[]
for p in Path('lib').rglob('*.dart'):
    s=p.read_text(errors='ignore')
    for asset in re.findall(r"['\"](assets/[^'\"]+)['\"]", s):
        if '*' in asset or '$' in asset: continue
        if not (root/asset).exists(): missing.append(f"{p}: {asset}")
if missing:
    print('[FAIL] missing Dart asset references:')
    print('\n'.join(missing))
    sys.exit(1)
print('[OK] Dart asset references resolve')
PY
[ $? -eq 0 ] || fail=1

# Server syntax checks if Node is available.
if command -v node >/dev/null 2>&1; then
  node --check server/src/server.js && node --check server/src/zegoToken.js && ok "Node syntax checks" || bad "Node syntax error"
else
  warn "Node.js unavailable; server syntax not executed"
fi

# Detect stale background extensions known to be wrong in this source.
if grep -RIn "assets/backgrounds/.*\.jpg" server lib >/dev/null 2>&1; then
  bad "stale .jpg background reference remains"
else
  ok "background references match shipped SVG assets"
fi

# Check ZIP-friendly root files.
for f in pubspec.yaml android lib server; do test -e "$f" || bad "archive root item missing: $f"; done

if [ "$fail" -eq 0 ]; then
  echo "AUDIT_RESULT=PASS"
else
  echo "AUDIT_RESULT=FAIL"
fi
exit "$fail"
