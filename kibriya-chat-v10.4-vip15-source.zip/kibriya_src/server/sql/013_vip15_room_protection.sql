-- VIP 15 room protections. Room owner and platform administrators retain moderation override.
UPDATE vip_levels
SET benefits = benefits || '{"kick_protection":true,"ban_protection":true,"royal_presence":true}'::jsonb
WHERE kind='VIP' AND id=15;
