-- Kibriya Chat v10.2: in-app notifications + seat themes
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(40) NOT NULL DEFAULT 'system',
  title VARCHAR(160) NOT NULL,
  body VARCHAR(500) NOT NULL,
  data JSONB NOT NULL DEFAULT '{}',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read) WHERE is_read=false;
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS seat_style VARCHAR(24) NOT NULL DEFAULT 'royal';
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS seat_color VARCHAR(16) NOT NULL DEFAULT 'gold';
