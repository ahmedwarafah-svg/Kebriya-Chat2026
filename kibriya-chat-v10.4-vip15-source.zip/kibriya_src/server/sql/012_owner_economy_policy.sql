-- Kibriya Chat v10.3: owner-only economy policy and annual review
CREATE TABLE IF NOT EXISTS economy_policies (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id=1),
  version VARCHAR(20) NOT NULL DEFAULT '1.0',
  title VARCHAR(160) NOT NULL DEFAULT 'سياسة اقتصاد ومكافآت كبرياء شات',
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  expires_at DATE NOT NULL DEFAULT (CURRENT_DATE + INTERVAL '1 year'),
  owner_pct NUMERIC(5,2) NOT NULL DEFAULT 40,
  host_pct NUMERIC(5,2) NOT NULL DEFAULT 25,
  agency_pct NUMERIC(5,2) NOT NULL DEFAULT 15,
  rewards_pct NUMERIC(5,2) NOT NULL DEFAULT 10,
  reserve_pct NUMERIC(5,2) NOT NULL DEFAULT 10,
  notes TEXT NOT NULL DEFAULT 'تُحسب نسب التوزيع من صافي المبلغ القابل للتوزيع بعد خصم رسوم المتجر/الدفع وتكاليف الخدمات الخارجية المعتمدة. تُراجع السياسة سنوياً.',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO economy_policies(id,version,title,effective_from,expires_at,owner_pct,host_pct,agency_pct,rewards_pct,reserve_pct,notes)
VALUES (1,'1.0','سياسة اقتصاد ومكافآت كبرياء شات',CURRENT_DATE,(CURRENT_DATE + INTERVAL '1 year')::date,40,25,15,10,10,'التوزيع يتم من صافي المبلغ القابل للتوزيع بعد خصم رسوم المتجر/الدفع وتكاليف الخدمات الخارجية المعتمدة. مراجعة سنوية مع إشعار المستخدمين بأي تغيير جوهري.')
ON CONFLICT(id) DO NOTHING;
